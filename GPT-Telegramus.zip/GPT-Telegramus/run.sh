#!/bin/bash
sudo dos2unix main.py
pip install -r requirements.txt --upgrade
python3 main.py
